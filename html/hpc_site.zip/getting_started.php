<?php include 'includes/header.php'; ?>
<section class="card">
  <h2>Getting Started</h2>
  <h3>Access</h3>
  <p>SSH to the login node:</p>
  <pre>ssh your-username@hpc.example.edu</pre>
  <h3>Requesting an account</h3>
  <p>Contact <code>hpc.helpdesk@ashoka.edu.in</code> with your affiliation and project details.</p>
  <h3>Environment Modules</h3>
  <p>Load modules with <code>module avail</code> and <code>module load &lt;name&gt;</code>. Example modules included:</p>
  <pre>apps/diamond/2.1.8
apps/lammps-stable_2Aug2023
compiler/gcc-11.2.0
compiler/nvhpc-nompi-22.7
library/HDF5
codes/enroot-3.2.0
codes/jq-1.6</pre>
</section>
<?php include 'includes/footer.php'; ?>