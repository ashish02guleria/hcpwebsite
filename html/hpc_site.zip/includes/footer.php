
</main>
<footer class="site-footer">
  <div class="container">
    <p>HPC Support: hpc.helpdesk@ashoka.edu.in | Mobile: 9805400405</p>
    <p>&copy; <?= date('Y') ?> HPC Cluster Documentation</p>
  </div>
</footer>
</body>
</html>
