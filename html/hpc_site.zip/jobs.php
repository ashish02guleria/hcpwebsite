<?php include 'includes/header.php'; ?>
<section class="card">
  <h2>Job Scheduling (Slurm)</h2>
  <h3>Submit a job</h3>
  <pre># example job script
#!/bin/bash
#SBATCH --job-name=example
#SBATCH --output=out.%j
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --time=01:00:00

module load gcc/11.2.0
srun ./my_program</pre>

  <h3>Common commands</h3>
  <ul>
    <li><code>squeue</code> - view queue</li>
    <li><code>scancel &lt;jobid&gt;</code> - cancel job</li>
    <li><code>sacct -j &lt;jobid&gt;</code> - job accounting</li>
  </ul>
</section>
<?php include 'includes/footer.php'; ?>