<?php include 'includes/header.php'; ?>
<section class="card">
  <h2>Software Available</h2>
  <p>Installed applications and libraries (examples):</p>
  <ul>
    <li>apps/diamond/2.1.8</li>
    <li>apps/lammps-stable_2Aug2023</li>
    <li>compiler/gcc-11.2.0</li>
    <li>compiler/nvhpc-nompi-22.7</li>
    <li>library/HDF5</li>
    <li>codes/enroot-3.2.0</li>
    <li>codes/jq-1.6</li>
  </ul>
  <h3>Requesting new software</h3>
  <p>Submit a ticket to the HPC team with software name, version, licensing info, and a use-case.</p>
</section>
<?php include 'includes/footer.php'; ?>