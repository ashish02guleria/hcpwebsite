<?php include 'includes/header.php'; ?>
<section class="card">
  <h2>FAQ & Troubleshooting</h2>
  <h3>Login issues</h3>
  <p>Check username, password, and that your account is activated. If using SSH keys, ensure permissions of <code>~/.ssh</code> are correct (700) and <code>~/.ssh/authorized_keys</code> is 600.</p>
  <h3>Job problems</h3>
  <p>Check output and error files. Use <code>scontrol show job &lt;id&gt;</code> for details.</p>
</section>
<?php include 'includes/footer.php'; ?>